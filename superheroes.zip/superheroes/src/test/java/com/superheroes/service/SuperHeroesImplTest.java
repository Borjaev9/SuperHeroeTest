package com.superheroes.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.superheroes.model.SuperHero;
import com.superheroes.repository.SuperHeroRepository;

import java.util.Optional;

@SpringBootTest
class SuperHeroServiceImplTest {

    @Mock
    private SuperHeroRepository superHeroRepository;

    @InjectMocks
    private SuperHeroServiceImpl superHeroService;

    @Test
    void testGetSuperHeroById() {
        // Configuración del mock
        SuperHero mockSuperHero = new SuperHero(1L, "MockHero");
        when(superHeroRepository.findById(1L)).thenReturn(Optional.of(mockSuperHero));

        // Llamada al servicio
        SuperHero result = superHeroService.getSuperHeroById(1L);

        // Verificación de resultados
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("MockHero", result.getName());

        // Verificación de interacción con el mock
        verify(superHeroRepository, times(1)).findById(1L);
    }

    @Test
    void testGetSuperHeroByIdNotFound() {
        // Configuración del mock para devolver Optional.empty()
        when(superHeroRepository.findById(2L)).thenReturn(Optional.empty());

        // Llamada al servicio
        SuperHero result = superHeroService.getSuperHeroById(2L);

        // Verificación de resultados
        assertNull(result);

        // Verificación de interacción con el mock
        verify(superHeroRepository, times(1)).findById(2L);
    }
}
