package com.superheroes;

import com.superheroes.model.SuperHero;
import com.superheroes.repository.SuperHeroRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SuperheroesApplication {

    public static void main(String[] args) {
        SpringApplication.run(SuperheroesApplication.class, args);
    }

    @Bean
    public CommandLineRunner initData(SuperHeroRepository superHeroRepository) {
        return args -> {
            // Agregar algunos superhéroes de ejemplo
        	superHeroRepository.save(new SuperHero(1L, "Spiderman"));
            superHeroRepository.save(new SuperHero(2L, "Superman"));
            superHeroRepository.save(new SuperHero(3L, "Batman"));
            superHeroRepository.save(new SuperHero(4L, "Wonder Woman"));
            superHeroRepository.save(new SuperHero(5L, "Iron Man"));
            superHeroRepository.save(new SuperHero(6L, "Thor"));
            superHeroRepository.save(new SuperHero(7L, "Black Widow"));
            superHeroRepository.save(new SuperHero(8L, "Captain America"));
            superHeroRepository.save(new SuperHero(9L, "Hulk"));
            superHeroRepository.save(new SuperHero(10L, "Flash"));
            // Puedes agregar más superhéroes según sea necesario
        };
    }
}
