package com.superheroes.service;

import com.superheroes.model.SuperHero;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface SuperHeroService {

	Page<SuperHero> getAllSuperHeroes(Pageable pageable);

    SuperHero getSuperHeroById(Long id);

    List<SuperHero> getSuperHeroesByName(String name);

    SuperHero createSuperHero(SuperHero superHero);

    SuperHero updateSuperHero(Long id, SuperHero updatedSuperHero);

    void deleteSuperHero(Long id);

}
