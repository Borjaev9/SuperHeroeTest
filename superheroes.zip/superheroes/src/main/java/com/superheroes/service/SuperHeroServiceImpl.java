package com.superheroes.service;

import com.superheroes.model.SuperHero;
import com.superheroes.repository.SuperHeroRepository;
import com.superheroes.service.SuperHeroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SuperHeroServiceImpl implements SuperHeroService {

    @Autowired
    private SuperHeroRepository superHeroRepository;

    @Override
    public Page<SuperHero> getAllSuperHeroes(Pageable pageable) {
        return superHeroRepository.findAll(pageable);
    }

    @Override
    public SuperHero getSuperHeroById(Long id) {
        Optional<SuperHero> optionalSuperHero = superHeroRepository.findById(id);
        return optionalSuperHero.orElse(null);
    }

    @Override
    public List<SuperHero> getSuperHeroesByName(String name) {
        return superHeroRepository.findByNameContaining(name);
    }

    @Override
    public SuperHero createSuperHero(SuperHero superHero) {
        return superHeroRepository.save(superHero);
    }

    @Override
    public SuperHero updateSuperHero(Long id, SuperHero updatedSuperHero) {
        // Verificar si el superhéroe con el ID dado existe
        SuperHero existingSuperHero = superHeroRepository.findById(id).orElse(null);

        if (existingSuperHero != null) {
            // Actualizar la información del superhéroe existente
            existingSuperHero.setName(updatedSuperHero.getName());
            // Puedes actualizar otras propiedades según sea necesario

            // Guardar el superhéroe actualizado en la base de datos
            return superHeroRepository.save(existingSuperHero);
        } else {
            // Manejar el caso donde el superhéroe con el ID dado no existe
            return null; // o lanzar una excepción, dependiendo de tus requisitos
        }
    }


    @Override
    public void deleteSuperHero(Long id) {
        superHeroRepository.deleteById(id);
    }
}
