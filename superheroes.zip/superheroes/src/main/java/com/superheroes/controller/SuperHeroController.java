package com.superheroes.controller;

import com.superheroes.model.SuperHero;
import com.superheroes.service.SuperHeroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/superheroes")
public class SuperHeroController {

    @Autowired
    private SuperHeroService superHeroService;

    @GetMapping
    public Page<SuperHero> getAllSuperHeroes(Pageable pageable) {
        return superHeroService.getAllSuperHeroes(pageable);
    }

    @GetMapping("/{id}")
    public SuperHero getSuperHeroById(@PathVariable Long id) {
        return superHeroService.getSuperHeroById(id);
    }

    @GetMapping("/search")
    public List<SuperHero> getSuperHeroesByName(@RequestParam String name) {
        return superHeroService.getSuperHeroesByName(name);
    }

    @PostMapping
    public SuperHero createSuperHero(@RequestBody SuperHero superHero) {
        return superHeroService.createSuperHero(superHero);
    }

    @PutMapping("/{id}")
    public SuperHero updateSuperHero(@PathVariable Long id, @RequestBody SuperHero updatedSuperHero) {
        return superHeroService.updateSuperHero(id, updatedSuperHero);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteSuperHero(@PathVariable Long id) {
        superHeroService.deleteSuperHero(id);
        return ResponseEntity.ok("SuperHero with ID " + id + " deleted successfully");
    }

}
